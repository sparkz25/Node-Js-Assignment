const fs = require("fs");
const xml2js = require('xml2js');

// read XML file
fs.readFile("empdatabase.xml", "utf-8", (err, data) => {
    if (err) {
        throw err;
    }

    // convert XML data to JSON object
    xml2js.parseString(data, (err, result) => {
        if (err) {
            throw err;
        }

        // print JSON object
        //console.log(JSON.stringify(result, null, 4));
		
		result.organisation.employee[0].company = 'Wipro Ltd';
		
		console.log(JSON.stringify(result, null, 4));
		
		// convert SJON objec to XML
        const builder = new xml2js.Builder();
        const xml = builder.buildObject(result);

        // write updated XML string to a file
        fs.writeFile('empdatabase_updated.xml', xml, (err) => {
            if (err) {
                throw err;
            }

            console.log(`Updated XML is written to a new file.`);
        });

    });
});
