'use strict';

const fs = require('fs');

let rawdata = fs.readFileSync('employee.json');
let employee = JSON.parse(rawdata);
console.log(employee);

employee.company = "Wipro Ltd"


let data = JSON.stringify(employee);
fs.writeFileSync('employeeupdated.json', data);