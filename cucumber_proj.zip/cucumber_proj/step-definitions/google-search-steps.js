const expect = require('chai').expect;
module.exports = function () {    
    this.When(/^I when I go to OpenCart url$/, () =>{
      return helpers.loadPage('https://demo.opencart.com/')
      .then( () => {
        return null        
      })
    }) 
    this.Then(/^I should see "([^"]*)" in the title of webpage\.$/, function (keywords) {
        return driver.wait(until.elementsLocated(by.xpath('//*[@id="logo"]/h1/a')), 10000);
    }); 
    this.When(/^I enter the "([^"]*)" and "([^"]*)" in field$/, function(username,password){
      console.log("username is ",username);
      driver.findElement(by.xpath('//*[@id="top-links"]/ul/li[2]/a')).click();
      driver.findElement(by.xpath('//*[@id="top-links"]/ul/li[2]/ul/li[2]/a')).click();
      driver.findElement(by.xpath('//*[@id="input-email"]')).sendKeys(username);
      driver.findElement(by.xpath('//*[@id="input-password"]')).sendKeys(password);
      return driver.findElement(by.xpath('//*[@id="top-links"]/ul/li[2]/a')).click().then( () => {
        return null
      })  
    });
    this.Then(/^I should get "([^"])*"error message\.$/, function(res){
      errmsg = driver.findElement(by.xpath('//*[@id="account-login"]/div[1]')).getText()
      return driver.wait(until.elementsLocated(by.xpath('//*[@id="account-login"]/div[1]')), 10000)
      .then(() => {
        driver.findElement(by.xpath('//*[@id="account-login"]/div[1]')).getText()
        .then(t => {
          try {
           expect(t).to.be.eql(res)
          }catch(e){return Promise.reject(false)}
        })        
      })
    })
};