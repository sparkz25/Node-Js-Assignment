
module.exports = {
  url: 'https://demo.opencart.com/',
  elements: {
    searchxpath_login: by.xpath('//*[@id="top-links"]/ul/li[2]/ul/li[2]/a'),
    searchxpath_login2: by.xpath(''),
    searchInput: by.name('q'),
    searchResultLink: by.css('div.g > h3 > a')
  },
  /**
   * enters a search term into Google's search box and presses enter
   * @param {string} searchQuery
   * @returns {Promise} a promise to enter the search values
   */
  clickLogin: function () {
    var selector = page.opencart.elements.searchxpath_login;
    // return a promise so the calling function knows the task has completed
    return driver.findElement(selector).click();
  }
};
